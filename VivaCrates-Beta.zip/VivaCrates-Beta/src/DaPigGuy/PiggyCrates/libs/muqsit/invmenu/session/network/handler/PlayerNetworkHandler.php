<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCrates\libs\muqsit\invmenu\session\network\handler;

use Closure;
use DaPigGuy\PiggyCrates\libs\muqsit\invmenu\session\network\NetworkStackLatencyEntry;

interface PlayerNetworkHandler{

	public function createNetworkStackLatencyEntry(Closure $then) : NetworkStackLatencyEntry;
}