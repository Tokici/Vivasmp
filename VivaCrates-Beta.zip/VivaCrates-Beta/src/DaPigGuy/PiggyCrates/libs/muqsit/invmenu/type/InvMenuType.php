<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCrates\libs\muqsit\invmenu\type;

use DaPigGuy\PiggyCrates\libs\muqsit\invmenu\InvMenu;
use DaPigGuy\PiggyCrates\libs\muqsit\invmenu\type\graphic\InvMenuGraphic;
use pocketmine\inventory\Inventory;
use pocketmine\player\Player;

interface InvMenuType{

	public function createGraphic(InvMenu $menu, Player $player) : ?InvMenuGraphic;

	public function createInventory() : Inventory;
}