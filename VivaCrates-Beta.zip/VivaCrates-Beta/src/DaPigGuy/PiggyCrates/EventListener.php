<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCrates;

use DaPigGuy\PiggyCrates\tiles\YkijiTile;
use DaPigGuy\PiggyCrates\tiles\CrateTile;
use pocketmine\block\BlockLegacyIds;
use pocketmine\block\tile\Chest;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use DaPigGuy\PiggyCrates\entity\CrateEntity;
use pocketmine\event\entity\EntityMotionEvent;

use pocketmine\block\tile\Beacon;
use pocketmine\block\tile\ShulkerBox;

class EventListener implements Listener
{
    private PiggyCrates $plugin;

    public function __construct(PiggyCrates $plugin)
    {
        $this->plugin = $plugin;
    }

    /**public function onInteract(PlayerInteractEvent $event): void
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $world = $block->getPosition()->getWorld();
        $item = $player->getInventory()->getItemInHand();

        if ($block->getId() === BlockLegacyIds::CHEST) {
            $tile = $world->getTile($block->getPosition());
            if ($tile instanceof CrateTile) {
                if ($tile->getCrateType() === null) {
                    $player->sendTip($this->plugin->getMessage("crates.error.invalid-crate"));
                } elseif ($tile->getCrateType()->isValidKey($item)) {
                    $tile->openCrate($player, $item);
                } elseif ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
                    $tile->previewCrate($player);
                }
                $event->cancel();
                return;
            }
            if ($tile instanceof Chest) {
                if (($crate = $this->plugin->getCrateToCreate($player)) !== null) {
                    $newTile = new CrateTile($world, $block->getPosition());
                    $newTile->setCrateType($crate);
                    $tile->close();
                    $world->addTile($newTile);
                    $player->sendMessage($this->plugin->getMessage("crates.success.crate-created", ["{CRATE}" => $crate->getName()]));
                    $this->plugin->setInCrateCreationMode($player, null);
                    $event->cancel();
                    return;
                }
            }
        }
        if ($item->getNamedTag()->getTag("KeyType") !== null) $event->cancel();
    }*/
    
    public function onTap(PlayerInteractEvent $event): void
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $world = $block->getPosition()->getWorld();
        $item = $player->getInventory()->getItemInHand();

        if ($block->getId() === BlockLegacyIds::UNDYED_SHULKER_BOX) {
            $tile = $world->getTile($block->getPosition());
            if ($tile instanceof CrateTile) {
                if ($tile->getCrateType() === null) {
                    $player->sendTip($this->plugin->getMessage("crates.error.invalid-crate"));
                } elseif ($tile->getCrateType()->isValidKey($item)) {
                    $tile->openCrate($player, $item);
                } elseif ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
                    $tile->previewCrate($player);
                }
                $event->cancel();
                return;
            }
            if ($tile instanceof ShulkerBox) {
                if (($crate = $this->plugin->getCrateToCreate($player)) !== null) {
                    $newTile = new CrateTile($world, $block->getPosition());
                    $newTile->setCrateType($crate);
                    $tile->close();
                    $world->addTile($newTile);
                    $player->sendMessage($this->plugin->getMessage("crates.success.crate-created", ["{CRATE}" => $crate->getName()]));
                    $this->plugin->setInCrateCreationMode($player, null);
                    $event->cancel();
                    return;
                }
            }
        }
        if ($item->getNamedTag()->getTag("KeyType") !== null) $event->cancel();
    }
    
    public function onClick(PlayerInteractEvent $event): void
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $world = $block->getPosition()->getWorld();
        $item = $player->getInventory()->getItemInHand();

        if ($block->getId() === BlockLegacyIds::BEACON) {
            $tile = $world->getTile($block->getPosition());
            if ($tile instanceof YkijiTile) {
                if ($tile->getCrateType() === null) {
                    $player->sendTip($this->plugin->getMessage("crates.error.invalid-crate"));
                } elseif ($tile->getCrateType()->isValidKey($item)) {
                    $tile->openCrate($player, $item);
                } elseif ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
                    $tile->previewCrate($player);
                }
                $event->cancel();
                return;
            }
            if ($tile instanceof Beacon) {
                if (($crate = $this->plugin->getCrateToCreate($player)) !== null) {
                    $newTile = new YkijiTile($world, $block->getPosition());
                    $newTile->setCrateType($crate);
                    $tile->close();
                    $world->addTile($newTile);
                    $player->sendMessage($this->plugin->getMessage("crates.success.crate-created", ["{CRATE}" => $crate->getName()]));
                    $this->plugin->setInCrateCreationMode($player, null);
                    $event->cancel();
                    return;
                }
            }
        }
        if ($item->getNamedTag()->getTag("KeyType") !== null) $event->cancel();
    }

public function onEntityMotion(EntityMotionEvent $event): void {
        $entity = $event->getEntity();
        if ($entity instanceof CrateEntity) {
            $event->cancel();
        }
    }
}