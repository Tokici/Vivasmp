<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCrates\commands;

use DaPigGuy\PiggyCrates\libs\CortexPE\Commando\args\RawStringArgument;
use DaPigGuy\PiggyCrates\libs\CortexPE\Commando\BaseCommand;
use DaPigGuy\PiggyCrates\libs\CortexPE\Commando\exception\ArgumentOrderException;
use DaPigGuy\PiggyCrates\PiggyCrates;
use DaPigGuy\PiggyCrates\entity\CrateEntity;
use pocketmine\command\CommandSender;
use pocketmine\entity\Entity;
use pocketmine\nbt\tag\ByteArrayTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\permission\DefaultPermissions;
use pocketmine\player\Player;

class VivaCommand extends BaseCommand
{
    /** @var PiggyCrates */
    protected $plugin;

    /**
     * @param array $args
     */
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) {
            $sender->sendMessage($this->plugin->getMessage("commands.use-in-game"));
            return;
        }
        if(!$sender->hasPermission(DefaultPermissions::ROOT_OPERATOR)){
            $sender->sendMessage($this->plugin->getMessage("commands.use-in-game"));
            return;
        }
        if(!isset($args["type"])){
        	$sender->sendMessage("Usage /viva <create|remove>");
        	return;
        }
        if($args["type"] == "create"){
        	$this->spawnCrate($sender);
        	$sender->sendMessage("§bGacha VivaSMP Npc created");
        } elseif($args["type"] == "remove"){
        	$VivaEntity = $this->getVivaEntity($sender);
			if($VivaEntity !== null){
				$VivaEntity->flagForDespawn();
				$sender->sendMessage("§bGacha VivaSMP Npc removed.");
				return;
			} else {
				$sender->sendMessage("There is no Gacha VivaSMP Entity in this World!");  
			}
        } else {
        	$sender->sendMessage("Usage /viva <create|remove>");
        return;
        }
    }
    
    public function spawnCrate(Player $sender){
        $skin = $sender->getSkin();
        $location = $sender->getLocation();
        $nbt = PiggyCrates::getInstance()->getNBT($sender, $location);
        $npc = new CrateEntity($location, $skin, $nbt);
        $npc->setSkin($skin);
        $nametag = "§l§eGacha";
		$npc->setNameTag($nametag);
        $npc->setNameTagAlwaysVisible(true);
        $npc->sendSkin(PiggyCrates::getInstance()->getServer()->getOnlinePlayers());
        $npc->spawnToAll();
	}
	
	public function getVivaEntity(Player $player) : ?CrateEntity{
		$level = $player->getWorld();
		foreach ($level->getEntities() as $entity){
			if($entity instanceof CrateEntity){
				if($player->getPosition()->distance($entity->getPosition()->asPosition()) <= 5 && $entity->getPosition()->distance($player->getPosition()->asPosition()) > 0){
					return $entity;
				}
			}
		}
		return null;
	}
    
    /**
     * @throws ArgumentOrderException
     */
    public function prepare(): void
    {
        $this->setPermission("piggycrates.command.viva");
        $this->registerArgument(0, new RawStringArgument("type"));
    }
}