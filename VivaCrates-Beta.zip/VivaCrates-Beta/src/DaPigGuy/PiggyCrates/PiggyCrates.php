<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCrates;

use DaPigGuy\PiggyCrates\libs\CortexPE\Commando\BaseCommand;
use DaPigGuy\PiggyCrates\libs\CortexPE\Commando\exception\HookAlreadyRegistered;
use DaPigGuy\PiggyCrates\libs\CortexPE\Commando\PacketHooker;
use DaPigGuy\PiggyCrates\commands\VivaCommand;
use DaPigGuy\PiggyCrates\commands\CrateCommand;
use DaPigGuy\PiggyCrates\commands\KeyAllCommand;
use DaPigGuy\PiggyCrates\commands\KeyCommand;
use DaPigGuy\PiggyCrates\crates\Crate;
use DaPigGuy\PiggyCrates\crates\CrateSlapper;
use DaPigGuy\PiggyCrates\entity\CrateEntity;
use DaPigGuy\PiggyCrates\crates\CrateItem;
use DaPigGuy\PiggyCrates\tasks\CheckUpdatesTask;
use DaPigGuy\PiggyCrates\tiles\CrateTile;
use DaPigGuy\PiggyCrates\tiles\YkijiTile;
use DaPigGuy\PiggyCrates\utils\Utils;
use DaPigGuy\PiggyCustomEnchants\CustomEnchantManager;
use DaPigGuy\PiggyCustomEnchants\PiggyCustomEnchants;
use Exception;
use DaPigGuy\PiggyCrates\libs\muqsit\invmenu\InvMenuHandler;
use pocketmine\block\tile\TileFactory;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\StringToEnchantmentParser;
use pocketmine\world\World;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\entity\Human;
use pocketmine\item\ItemFactory;
use pocketmine\nbt\JsonNbtParser;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\ClosureTask;
use pocketmine\utils\Config;
use pocketmine\math\Vector3;

class PiggyCrates extends PluginBase
{
    private static PiggyCrates $instance;

    private Config $messages;

    /** @var Crate[] */
    public array $crates = [];
    /** @var CrateTile[] */
    public array $crateTiles = [];
    /** @var Array<string, Crate> */
    public array $crateCreation;

    /**
     * @throws HookAlreadyRegistered
     */
    public function onEnable(): void
    {
        foreach (
            [
                "Commando" => BaseCommand::class,
                "InvMenu" => InvMenuHandler::class
            ] as $virion => $class
        ) {
            if (!class_exists($class)) {
                $this->getLogger()->error($virion . " virion not found. Please download PiggyCrates from Poggit-CI or use DEVirion (not recommended).");
                $this->getServer()->getPluginManager()->disablePlugin($this);
                return;
            }
        }

        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }

        self::$instance = $this;
        
        $entityFactory = EntityFactory::getInstance();
        $entityFactory->register(CrateEntity::class, static function(World $world, CompoundTag $nbt): CrateEntity{
            return new CrateEntity(EntityDataHelper::parseLocation($nbt, $world), Human::parseSkinNBT($nbt), $nbt);
        }, ['CrateEntity']);
        TileFactory::getInstance()->register(YkijiTile::class);
        TileFactory::getInstance()->register(CrateTile::class);

        $this->saveResource("crates.yml");
        $this->saveResource("messages.yml");
        $this->messages = new Config($this->getDataFolder() . "messages.yml");
        $this->saveDefaultConfig();

        $crateConfig = new Config($this->getDataFolder() . "crates.yml");
        $types = ["item", "command"];
        foreach ($crateConfig->get("crates") as $crateName => $crateData) {
            $this->crates[$crateName] = new Crate($this, $crateName, $crateData["floating-text"] ?? "", array_map(function (array $itemData) use ($crateName, $types): CrateItem {
                $tags = null;
                if (isset($itemData["nbt"])) {
                    try {
                        $tags = JsonNbtParser::parseJson($itemData["nbt"]);
                    } catch (Exception $e) {
                        $this->getLogger()->warning("Invalid crate item NBT supplied in crate type " . $crateName . ".");
                    }
                }
                $item = ItemFactory::getInstance()->get($itemData["id"], $itemData["meta"], $itemData["amount"], $tags);
                if (isset($itemData["name"])) $item->setCustomName($itemData["name"]);
                if (isset($itemData["lore"])) $item->setLore(explode("\n", $itemData["lore"]));
                if (isset($itemData["enchantments"])) foreach ($itemData["enchantments"] as $enchantmentData) {
                    if (!isset($enchantmentData["name"]) || !isset($enchantmentData["level"])) {
                        $this->getLogger()->error("Invalid enchantment configuration used in crate " . $crateName);
                        continue;
                    }
                    $enchantment = StringToEnchantmentParser::getInstance()->parse($enchantmentData["name"]) ?? ((($plugin = $this->getServer()->getPluginManager()->getPlugin("PiggyCustomEnchants")) instanceof PiggyCustomEnchants && $plugin->isEnabled()) ? CustomEnchantManager::getEnchantmentByName($enchantmentData["name"]) : null);
                    if ($enchantment !== null) $item->addEnchantment(new EnchantmentInstance($enchantment, $enchantmentData["level"]));
                }
                $itemData["type"] = $itemData["type"] ?? "item";
                if (!in_array($itemData["type"], $types)) {
                    $itemData["type"] = "item";
                    $this->getLogger()->warning("Invalid crate item type supplied in crate type " . $crateName . ". Assuming type item.");
                }
                return new CrateItem($item, $itemData["type"], $itemData["commands"] ?? [], $itemData["chance"] ?? 100);
            }, $crateData["drops"] ?? []), $crateData["amount"], $crateData["commands"] ?? []);
        }

        if (!PacketHooker::isRegistered()) PacketHooker::register($this);
        $this->getServer()->getCommandMap()->register("piggycrates", new VivaCommand($this, "viva", "Create a viva slapper"));
        $this->getServer()->getCommandMap()->register("piggycrates", new CrateCommand($this, "crate", "Create a crate"));
        $this->getServer()->getCommandMap()->register("piggycrates", new KeyCommand($this, "key", "Give a crate key"));
        $this->getServer()->getCommandMap()->register("piggycrates", new KeyAllCommand($this, "keyall", "Give all online players a crate key"));

        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);

        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function () {
            foreach ($this->crateTiles as $crateTile) {
                if(!$crateTile instanceof CrateSlapper) {
                    $crateTile->onUpdate();
                }
                
            }
        }), 20);
        $this->getServer()->getAsyncPool()->submitTask(new CheckUpdatesTask());
    }

    public static function getInstance(): PiggyCrates
    {
        return self::$instance;
    }

    public function getMessage(string $key, array $tags = []): string
    {
        return Utils::translateColorTags(str_replace(array_keys($tags), $tags, $this->messages->getNested($key, $key)));
    }

    public function getCrate(string $name): ?Crate
    {
        return $this->crates[$name] ?? null;
    }

    public function getCrates(): array
    {
        return $this->crates;
    }

    public function inCrateCreationMode(Player $player): bool
    {
        return isset($this->crateCreation[$player->getName()]);
    }

    public function setInCrateCreationMode(Player $player, ?Crate $crate): void
    {
        if ($crate === null) {
            unset($this->crateCreation[$player->getName()]);
            return;
        }
        $this->crateCreation[$player->getName()] = $crate;
    }

    public function getCrateToCreate(Player $player): ?Crate
    {
        return $this->crateCreation[$player->getName()] ?? null;
    }
    
    public function getNBT(Player $player, $location){
        $nbt = $this->createBaseNBT($location->asVector3(), null, $location->getYaw(), $location->getPitch());
        $nbt->setTag("Skin", CompoundTag::create()
            ->setString("Name", $player->getSkin()->getSkinId())
            ->setByteArray("Data", $player->getSkin()->getSkinData())
            ->setByteArray("CapeData", $player->getSkin()->getCapeData())
            ->setString("GeometryName", $player->getSkin()->getGeometryName())
            ->setByteArray("GeometryData", $player->getSkin()->getGeometryData())
        );
        return $nbt;
    }
    
    public function createBaseNBT(Vector3 $pos, ?Vector3 $motion = null, float $yaw = 0.0, float $pitch = 0.0): CompoundTag {
        return CompoundTag::create()
            ->setTag("Pos", new ListTag([
                new DoubleTag($pos->x),
                new DoubleTag($pos->y),
                new DoubleTag($pos->z)
            ]))
            ->setTag("Motion", new ListTag([
                new DoubleTag($motion !== null ? $motion->x : 0.0),
                new DoubleTag($motion !== null ? $motion->y : 0.0),
                new DoubleTag($motion !== null ? $motion->z : 0.0)
            ]))
            ->setTag("Rotation", new ListTag([
                new FloatTag($yaw),
                new FloatTag($pitch)
            ]));
    }
}