<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCrates\entity;

use pocketmine\entity\Human;
use pocketmine\entity\Location;
use pocketmine\entity\Skin;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataProperties;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataTypes;
use pocketmine\world\World;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\protocol\SetActorDataPacket as SetEntityDataPacket;
use pocketmine\network\mcpe\convert\SkinAdapterSingleton;
use pocketmine\player\Player;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;

use DaPigGuy\PiggyCrates\crates\CrateSlapper;

class CrateEntity extends Human {
    
	/**
	 * @param EntityDamageEvent $source
	 */
	public function attack(EntityDamageEvent $source): void
	{
		$source->cancel();
		if($source instanceof EntityDamageByEntityEvent){
			if($source->getDamager() instanceof Player){
		    	$crate = new CrateSlapper();
		  	  $item = $source->getDamager()->getInventory()->getItemInHand();
		   	 if($crate->getCrateType()->isValidKey($item)){
		       	 $crate->openCrate($source->getDamager(), $item);
			    } else {
		      	  $crate->previewCrate($source->getDamager());
		   	 }
			}
		}
	}
}
